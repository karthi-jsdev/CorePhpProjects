<?php
	include("Config.php");
	echo 'sd';
?>