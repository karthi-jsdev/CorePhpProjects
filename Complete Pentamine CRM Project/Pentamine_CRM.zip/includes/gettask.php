<?php 
	include("config.php");
	if(isset($_GET['status']))
		$sql = mysql_query("SELECT * FROM task WHERE taskid IN (SELECT tskid FROM taskcomments WHERE tstatus ='".$_GET['status']."' AND enable=1) OR status='".$_GET['status']."' ORDER BY tdate desc");
	else if(isset($_GET['assignee']))	
		$sql = mysql_query("SELECT * FROM task WHERE assignee='".$_GET['assignee']."' AND taskid NOT IN(SELECT tskid FROM taskcomments WHERE tstatus ='Closed' AND enable=1) ORDER BY tdate desc");	
	else if(isset($_GET['assignee1']))
		$sql = mysql_query("SELECT * FROM task WHERE assignee='".$_GET['assignee1']."' AND taskid IN(SELECT tskid FROM taskcomments WHERE tstatus ='Closed' AND enable=1) ORDER BY tdate desc");
	else	
		$sql = mysql_query("SELECT * FROM task ORDER BY tdate desc");
	if(isset($_GET['assignee']))
		$getassignee = $_GET['assignee'];
	else if(isset($_GET['assignee1']))
		$getassignee = $_GET['assignee1'];
	if(isset($getassignee))	
		$getAssignee = mysql_fetch_array(mysql_query("SELECT * FROM assignee WHERE id='".$getassignee."'"));
	if(mysql_num_rows($sql))
	{
		if(isset($_GET['status']))
			echo "<table><tr><td><h1>Task Summary of ".$_GET['status']." </h1><td></tr></table>#";
		else if(isset($_GET['assignee']))
			echo "<table><tr><td><h1>Task Summary of ".$getAssignee['name']." </h1><td></tr></table>#";
		else if(isset($_GET['assignee1']))
			echo "<table><tr><td><h1>Task Summary of ".$getAssignee['name']." And Closed Tasks </h1><td></tr></table>#";
		else
			echo "<table><tr><td><h1>Task Summary of All </h1><td></tr></table>#";
			
		echo "<table  border='1'  align='left' class='paginate sortable full'>
			<tr>
				<th align='center'>Task-ID</th>
				<th align='center'>Client</th>
				<th align='center'>Task Date</th>
				<th align='center'>Task Description</th>
				<th align='center'>Target Date</th>
				<th align='center'>Assignee</th>
				<th align='center'>Status</th>
			</tr>";
		while($row = mysql_fetch_array($sql))
		{
			echo "<tr>
			<td align='center'><a href='?page=taskstatus&id=".$row['taskid']."&ptclid=".$row['ptclid']."'>".$row['taskid']."</a></td>";
			if($row['ptclid'] != "Others")
			{
				$client_id = mysql_fetch_array(mysql_query("SELECT * FROM lead WHERE ptclid='".$row['ptclid']."' "));
				$client_name = mysql_fetch_array(mysql_query("SELECT * FROM client WHERE ptcid='".$client_id['cname']."' "));
				echo "<td align='center'>".$client_name['cname']."</td>";
			}
			else
				echo "<td align='center'>".$row['ptclid']."</td>";
				
			echo "<td align='center'>".$row['taskdate']."</td>
			<td align='center'>".$row['tdesc']."</td>
			<td align='center'>".$row['tdate']."</td>";
			$query1 = mysql_query("SELECT * FROM assignee  where id='".$row['assignee']."'");
			$row1=mysql_fetch_array($query1);
			echo "<td align='center'>".$row1['name']."</td>";
			$status_id = mysql_fetch_array(mysql_query("Select * From taskcomments Where tskid='".$row['taskid']."' AND enable=1"));
			if($status_id)
				echo "<td align='center'>".$status_id['tstatus']."</td>";
			else
				echo "<td align='center'>Open</td>";
			echo "</tr>";	
		}	
		echo "</table>";
	}
	else
	{
		echo "#<table  border='1'  align='left' class='paginate sortable full'>
		<tr><td></td><td>";
		echo "No Tasks Found</td></tr>
		</table>";
	}
?>