

<html>
	<link rel="stylesheet" type="text/css" href="style.css">
		<body>
			
		</body>

			<h1>
				PENTAMINE CUSTOMER MANAGEMENT  SYSTEM
			</h1>
</html>
<?php
	echo "<table border='1' align='center' align='middle' >
			<tr>
				<th> CLIENT</th> 	<th>MASTER</th> <th> LEAD </th>  
			</tr>
			<tr>
				<td><a href='client.php' style='text-decoration:none;' target='_SELF'>Client</a></td></td>
				<td><a href='master.php' style='text-decoration:none;' target='_SELF'>Products</a></td>
				<td><a href='lead.php' style='text-decoration:none;' target='_SELF'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Lead</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				<td><a href='leadstatus.php' style='text-decoration:none;' target='_SELF'>Lead Status</a></td>
				<td><a href='leadsummary.php' style='text-decoration:none;' target='_SELF'>Lead Summary</a></td></td>
				
			</tr>
		</table>";
?>