<?php
require("classes/manage_database.php");
require("functions/general.php");
require("functions/upload.php");
$db = new Database();
?>
