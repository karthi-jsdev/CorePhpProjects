<html>
	<h1>
		Employee Status
	</h1>
	<body>
	<table>
		<tr>
			<td>
				Description:
			</td>
			<td>
				<textarea rows='2' cols='10'></textarea>
			</td>
		</tr>	
	</table>	
	</body>

</html>