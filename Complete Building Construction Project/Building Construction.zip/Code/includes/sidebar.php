 <aside class="grid_2">
    <div id="rightmenu" class="panel">
        <header>
            <h2>Your Account: Free Trial</h2>
        </header>
        <dl>
            <dt>Bandwidth: 10000/100000 MB</dt>
            <dd><div class="progress progress-green"><span style="width: 10%;"><b>10%</b></span></div></dd>
            <dt>Storage: 500/1000 MB</dt>
            <dd><div class="progress progress-green"><span style="width: 50%;"><b>50%</b></span></div></dd>
            <dt>Users: 3/5</dt>
            <dd><div class="progress progress-orange"><span style="width: 60%;"><b>60%</b></span></div></dd>
            <dt>Emails Sent: 900/1000</dt>
            <dd><div class="progress progress-red"><span style="width: 90%;"><b>90%</b></span></div></dd>
        </dl>
        <br />
        <div class="ar">
			<a class="button button-blue" href="pricing.html">Upgrade Plan &raquo;</a>
        </div>
    </div>

    <div class="widget">
        <header>
            <h2>Updates</h2>
        </header>
        <section>
            <dl>
                <dt>XtremeAdmin v1.2 Released! </dt>
                <dd><a href="#">Read more</a></dd>
                <dt>XtremeAdmin v1.1 Released! </dt>
                <dd><a href="#">Read more</a></dd>
                <dt>XtremeAdmin v1 Released!</dt>
                <dd><a href="#">Read more</a></dd>
            </dl>
        </section>
    </div>
</aside>