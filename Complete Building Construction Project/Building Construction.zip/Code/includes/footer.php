<footer id="page-footer">
	<div id="footer-inner">
	    <p class="wrapper"><span style="float: right;"><a href="#">Documentation</a> | <a href="#">Feedback</a></span>Last account activity from 127.0.0.1 - <a href="#">Details</a> | &copy; 2010. All rights reserved.</p>
	</div>
</footer>
