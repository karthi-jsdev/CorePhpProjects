<?php
	include("Config.php");
	include("Complaint_Queries.php");
	if(isset($_GET['Department']) && ($_GET['Group']))
	{
	$Extension = mysql_fetch_array(mysql_query("Select * From department where id='".$_GET['Department']."'"));
		echo $Extension['extension'].'#<select id="location" name="location">
				<option value="">Select</option>';
				$ComplaintSelect_Locations = Complaint_Select_Location($_GET['Department'],$_GET['Group']);
				if(mysql_num_rows($ComplaintSelect_Locations))
				{
					while($ComplaintSelect_Locations_ByGroupDepartment = mysql_fetch_array($ComplaintSelect_Locations))
						echo '<option value="'.$ComplaintSelect_Locations_ByGroupDepartment['id'].'">'.$ComplaintSelect_Locations_ByGroupDepartment['name'].'</option>';
				}
			echo '</select>';
	}
?>