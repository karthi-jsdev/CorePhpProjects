<?php
	include("Config.php");
	include("Complaint_Queries.php");
	if(isset($_GET['Department']) && ($_GET['Group']))
	{
	$Extension = mysql_fetch_array(mysql_query("Select * From department where id='".$_GET['Department']."'"));
		echo $Extension['extension'];
	}
?>