<?php
	//Master : assets
	function Assets_Select_ById($Id)
	{
		return mysql_query("SELECT * FROM assets WHERE id='".$Id."'");
	}
	function Assets_Delete_ById($Id)
	{
		return mysql_query("DELETE FROM assets WHERE id='".$Id."'");
	}
	function Assets_Insert($divisionid, $departmentid,$locationid,$itemid,$itemname,$itemdescription,$connectiontype,$purchasedat,$warrantydate,$amcperiod,$condemned,$standby,$softwareids,$ipaddress)
	{
		if($locationid)
			return mysql_query("insert into assets(divisionid,departmentid, locationid,itemid,itemname,itemdescription,connectiontype,purchasedat,warrantydate,amcperiod,condemned,standby,softwareids,ipaddress) values('".$divisionid."', '".$departmentid."','".$locationid."','".$itemid."','".$itemname."','".$itemdescription."','".$connectiontype."','".date('Y-m-d',strtotime($purchasedat))."','".date('Y-m-d',strtotime($warrantydate))."','".$amcperiod."','".$condemned."','".$standby."','".$softwareids."','".$ipaddress."')");
		else
			return mysql_query("insert into assets(divisionid,departmentid,itemid,itemname,itemdescription,connectiontype,purchasedat,warrantydate,amcperiod,condemned,standby,softwareids,ipaddress) values('".$divisionid."', '".$departmentid."','".$itemid."','".$itemname."','".$itemdescription."','".$connectiontype."','".date('Y-m-d',strtotime($purchasedat))."','".date('Y-m-d',strtotime($warrantydate))."','".$amcperiod."','".$condemned."','".$standby."','".$softwareids."','".$ipaddress."')");
	}
	function Assets_Update($Id,$divisionid,$departmentid,$locationid,$itemid,$itemname,$itemdescription,$connectiontype,$purchasedat,$warrantydate,$amcperiod,$condemned,$standby,$softwareids,$ipaddress)
	{
		if($locationid)
			return mysql_query("UPDATE assets SET divisionid='".$divisionid."',departmentid='".$departmentid."',locationid='".$locationid."', itemid='".$itemid."', itemname='".$itemname."', itemdescription='".$itemdescription."', connectiontype='".$connectiontype."',purchasedat='".date('Y-m-d',strtotime($purchasedat))."',warrantydate='".date('Y-m-d',strtotime($warrantydate))."', amcperiod='".$amcperiod."', condemned='".$condemned."', standby='".$standby."', softwareids='".$softwareids."', ipaddress='".$ipaddress."' WHERE id='".$Id."'");
		else
			return mysql_query("UPDATE assets SET divisionid='".$divisionid."',departmentid='".$departmentid."', itemid='".$itemid."', itemname='".$itemname."', itemdescription='".$itemdescription."', connectiontype='".$connectiontype."',purchasedat='".date('Y-m-d',strtotime($purchasedat))."',warrantydate='".date('Y-m-d',strtotime($warrantydate))."', amcperiod='".$amcperiod."', condemned='".$condemned."', standby='".$standby."', softwareids='".$softwareids."', ipaddress='".$ipaddress."' WHERE id='".$Id."'");
	}
	function Assets_Select_All()
	{
		return mysql_query("SELECT * FROM assets ORDER BY id DESC");
	}
	function Assets_Select_AllBySearch($Search)
	{
		return mysql_query("SELECT * FROM assets WHERE itemname like '".$Search."%'  or itemname like '%".$Search."' or itemname like '%".$Search."%'ORDER BY id DESC");
	}
	function Assets_Select_ByLimit($Start, $Limit)
	{
		return mysql_query("SELECT * FROM assets ORDER BY id DESC LIMIT $Start, $Limit");
	}
	function Assets_Select_ByLimitSearch($Search,$Start, $Limit)
	{
		return mysql_query("SELECT * FROM assets WHERE itemname like '".$Search."%'  or itemname like '%".$Search."' or itemname like '%".$Search."%' ORDER BY id DESC LIMIT $Start, $Limit");
	}
	function Assets_Select_Division()
	{
		return mysql_query("SELECT * FROM division ORDER BY name asc");
	}
	function Assets_Get_DepartmentById($DivisionId)
	{
		return mysql_query("SELECT * FROM department where divisionid = '".$DivisionId."' ORDER BY name asc");
	}
	function Assets_Get_LocationById($LocationId)
	{
		return mysql_query("SELECT * FROM location where departmentid = '".$LocationId."' ORDER BY name asc");
	}
	function Assets_Select_item_All()
	{
		return mysql_query("SELECT * FROM item ORDER BY name asc");
	}
	function Asset_Division_BYId($DivisionId)
	{
		return mysql_query("SELECT * FROM division Where id='".$DivisionId."' ORDER BY name asc");
	}
	function Assets_DepartmentById($DepartmentId)
	{
		return mysql_query("SELECT * FROM department where id = '".$DepartmentId."' ORDER BY name asc");
	}
	function Assets_LocationById($LocationId)
	{
		return mysql_query("SELECT * FROM location where id = '".$LocationId."' ORDER BY name asc");
	}
	function Assets_itemById($Id)
	{
		return mysql_query("SELECT * FROM item where id = '".$Id."' ORDER BY id asc");
	}
	function Asset_Select_All_Complaint($Id)
	{
		return mysql_query("SELECT * FROM complaint where itemid = '".$Id."' ORDER BY id DESC");
	}
	function Assets_Select_All_Name($name)
	{
		return mysql_query("SELECT * FROM assets where itemname = '".$name."' ORDER BY id DESC");
	}
	// Asset Status
	function Assets_Status_Insert($assetid, $assetdescription,$statusid)
	{
		return mysql_query("insert into assetstatus(assetid,assetdescription,statusid,datetime) values('".$assetid."', '".$assetdescription."','".$statusid."','".date('Y-m-d H:i:s')."')");
	}	
	function Assets_Status_Select_ById($Id)
	{
		return mysql_query("select * from assetstatus where assetid='".$Id."' order by id desc");
	}
	function Assets_Status_Select_ByItemName($Name,$Start, $Limit)
	{
		return mysql_query("select * from assets where itemname like '".$Name."%' or itemname like '% ".$Name."'  or itemname like '% ".$Name." %' order by id desc Limit $Start, $Limit");
	}
	function Assets_Status_Select_ByName($Name)
	{
		return mysql_query("select * from assets where itemname like '".$Name."%' or itemname  like '% ".$Name."'  or itemname like '% ".$Name." %'  order by id desc");
	}
	function Complaint_Get_Status()
	{
		return mysql_query("select * from status WHERE id<>8 ");
	}
	function Complaint_Get_Status_Select_ById($Id)
	{
		return mysql_query("select * from status where id='".$Id."'");
	}
	//Software in Asset
	function Softwares_Select_All()
	{
		return mysql_query("SELECT * FROM softwares ORDER BY name asc");
	}
	function Softwares_Select_ById($Conditions)
	{
		return mysql_query("SELECT * FROM softwares WHERE ".$Conditions." ORDER BY name asc");
	}
	function Assets_Location()
	{
		return mysql_query("SELECT * FROM location ORDER BY name asc");
	}
	function  Assets_Department()
	{
		return mysql_query("SELECT * FROM department ORDER BY name asc");
	}	
?>