<!-- Left column/section -->
<section class="grid_6 first">
    <div class="columns">
        <div class="grid_6 first">
        	<form id="form" class="form panel">
                <header><h2>Mail Us</h2></header>
                <hr />
                <fieldset>
					<div class="clearfix">
						<label>Yor Name <font color="red">*</font></label><input type="text" name="username" required="required" />
					</div>
					<div class="clearfix">
						<label>Email ID <font color="red">*</font></label><input type="email" required="required" />
					</div>
					<div class="clearfix">
						<label>website</label><input type="url" required="required" />
					</div>
					<div class="clearfix">
						<label>Message</label><textarea rows="5" cols="80"></textarea>
					</div>
                </fieldset>
                <hr />
                <button class="button button-blue" type="submit">Submit form</button>
                <button class="button button-gray" type="reset">Reset</button>
            </form>
        </div>
    </div>

    <div class="clear">&nbsp;</div>
</section>