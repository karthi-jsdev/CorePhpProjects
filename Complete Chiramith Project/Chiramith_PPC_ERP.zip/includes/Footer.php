<footer id="page-footer">
	<div id="footer-inner">
	    <p class="wrapper"><span style="float: right;"></span>Last account activity from <?php echo $_SERVER['SERVER_ADDR'];?> - &copy; <?php echo date("Y"); ?>. Designed and developed by <a href="http://www.pentamine.com" target="_blank">Pentamine Technologies Pvt. Ltd.</a>.</p>
	</div>
</footer>