<?php
	function Select_Category()
	{
		return mysql_query("Select * from miscellaneous");
	}
?>